# Prerequisites

- ACADO Toolkit for Matlab.
- qpOASES for matlab (included folder should be enough but its better if you install it properly)


Check Quad_mpc_acado.mlx for more details


